package ex02variable;

public class E04StringType_03 {

	public static void main(String[] args) {
		
		int num1 = 99;
		
		System.out.println("클래스지만 기본자료형처럼 사용");

	}

}
