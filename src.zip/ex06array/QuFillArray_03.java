package ex06array;

public class QuFillArray_03 {

	public static void main(String[] args) {
		
		int[]arr = new int[10];
		int[]sit = new int[10];
		
		for(int i=0; i<arr.length; i++) {
			arr[i] = i+1;
		}
		
		System.out.print("순서대로입력된결과 : ");
		for(int i: arr) {
			System.out.print(i + " ");
		}
		
		System.out.print("\n홀수/짝수 구분입력결과 : ");
		for(int i: arr) {
			if(i%2 == 0) {
				for(int b=9; b==0; b--) {
					sit[b] = i;
					System.out.print(i + " ");
				}
			}
			else {
				for(int c=0; c==9; c++) {
					sit[c] = i;
					System.out.print(i + " ");
					
				}
				
			}
		}

	}

}
