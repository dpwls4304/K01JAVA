package ex01start;

public class E02ex {

	public static void main(String[] args) {
		
		int ber1 = 50;
		
		System.out.println("ber1="+ber1);
		System.out.print("ber1="+ ber1 +"\n");
		System.out.printf("ber1=%d%n", ber1);
		
		System.out.println(0.4);
		System.out.println(4);
		
		System.out.println(4 + 6);//10
		System.out.println(2.5 + 2.5);//5
		
		System.out.println("2+4="+ 6);
		System.out.println(2 + "는 정수입니다.");
		
		System.out.println("3+3" + " 의 연산결과는 6입니다.");
		
		System.out.println("ber1 은"+ ber1 + "입니다.");

	}

}
