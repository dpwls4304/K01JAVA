package ex07string;

public class E02StringMethod {

	public static void main(String[] args) {
		
		System.out.println("String 클래스의 주요 메소드");
		
		String str1 = "Welcom to java";
		String str2 = "자바야 놀자!";
		
		/*
		 1] length() : 문자열의 길이를 반환한다.
		 */
		System.out.println("str1의 길이:" + str1.length());
		System.out.println("str2의 길이:" + str2.length());
		
		/*
		 2] charAt(인덱스) : 문자열에서 특정 index에 해당하는
		 	문자 하나를 반환한다. index는 0부터 시작한다.
		 */
		System.out.println("str1의 두번째 문자:" 
				+ str1.charAt(1));
		System.out.println("str2의 두번째 문자:" 
				+ str2.charAt(1));
		
		/*
		 시나리오] 주민등록번호를 이용하여 성별을 판단하는
		 프로그램을 작성하시오.
		 190419-3000000 => 남자
		 190419-4000000 => 여자
		 */
		String juminNum = "190419-5000000";
		if(juminNum.charAt(7)=='1' 
				|| juminNum.charAt(7)=='3') {
			System.out.println("남자입니다");
		}
		else if(juminNum.charAt(7)=='2' 
				|| juminNum.charAt(7)=='4') {
			System.out.println("여자입니다.");
		}
		else if(juminNum.charAt(7)=='5' 
				|| juminNum.charAt(7)=='6') {
			System.out.println("외국인입니다.");
		}
		else {
			System.out.println("주민번호가 잘못되었습니다.");
		}
		
		/*
		 4] compareTo() : 두 문자열을 첫번째 문자부터 순차적으로
		 	비교하면서
		 		앞의 문자열의 아스키코드가 크면 양수를 반환
		 		뒤의 문자열의 아스키코드가 크면 음수를 반환
		 		같으면 0을 반환한다.
		 */
		String str3 = "A";
		String str4 = "B";
		System.out.println(str3.compareTo(str4));
		System.out.println(str4.compareTo(str3));
		System.out.println("ABC".compareTo("ABC")==0 ?
				"문자열이같다" : "문자열이다르다");
		/*
		 5] concat() : 두개의 문자열을 연결할때 사용한다. +기호와
		 	동일한 역할을 한다.
		 */
		System.out.println("JAVA".concat(" WROLD").concat(" Go"));
		System.out.println("JAVA"+" WORLD"+" GO");
		
		/*
		 6] contains() : 문자열에 특정 문자열이 포함되어있는지
		 	판단하여 포함되었으면 true, 아니면 false를 반환한다.
		 */
		System.out.println(str1.contains("To"));
		System.out.println(str1.contains("to"));
		
		/*
		 시나리오] 해당 문자열이 이메일 형식인지 검사하는
		 프로그램을 작성하시오.
		 hong@ikosmo.co.kr => 이메일 형식임
		 not@naver => 이메일형식이 아님
		 */
		
		String email1 = "hong@ikosmo.co.kr";
		if(email1.contains("@") && email1.contains(".")) {
			System.out.println("이메일형식임");
		}
		else {
			System.out.println("이메일형식이아님");
		}

	}

}
